// tresor_t.cpp: Zum Testen der Klassen Tresor und Castle
// ------------------------------------------------------
#include "tresor.h"

int main()
{
   Castle schatulle;

   schatulle.display();

   schatulle.test();
   schatulle.display();
   
   return 0;
}
