// kfz.cpp
// Implementierung der Methoden von Kfz und Pkw
// ------------------------------------------------------
#include "kfz.h"

Kfz::Kfz( long n, const string& herst)
{
    nr = n;
    hersteller = herst;
}

void Kfz::display() const
{
    cout << "\n---------------------------- "
         << "\nKfz-Nummer:   " << nr
         << "\nHersteller:   " << hersteller
         << endl;
}

// Erste Version des Konstruktors von Pkw
// ---------------------------------------
// Pkw::Pkw(const string& tp, bool sd, int n, const string& hs)
// {
//    setNr(n);       // Anfangswerte f�r Datenelemente
//    setHerst(hs);   // der Basisklasse.
//    
//    pkwTyp  = tp;   // Anfangswerte f�r Datenelemente
//    schiebe = sd;   // der abgeleiteten Klasse
// }


// Zweite Version des Konstruktors von Pkw
// ----------------------------------------------------
// Pkw::Pkw(const string& tp, bool sd, int n, const string& hs)
//     : Kfz( n, hs)
// {
//    pkwTyp  = tp;     // Anfangswerte f�r Datenelemente
//    schiebe = sd;     // der abgeleiteten Klasse
// }


// Dritte Version des Konstruktors von Pkw
// ----------------------------------------------------
Pkw::Pkw(const string& tp, bool sd, int n, const string& hs)
    : Kfz( n, hs), pkwTyp(tp), schiebe(sd) 
{
   // Hier ist nichts mehr zu tun.
}


void Pkw::display( void) const
{
   Kfz::display();            // Methode der Basisklasse

   cout << "Typ:          " << pkwTyp;
   cout << "\nSchiebedach: ";  
   if(schiebe)
       cout << " ja "<< endl;
   else
       cout << " nein " << endl;
}
